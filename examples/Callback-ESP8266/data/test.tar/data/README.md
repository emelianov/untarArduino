# untarArduino

Extremely simple tar extractor

# Disclamber

This code based on
 
"untar" is an extremely simple tar extractor

Written by Tim Kientzle, March 2009.

Released into the public domain.

Original code taken from https://opensource.apple.com/source/libarchive/libarchive-30/libarchive/contrib/untar.c

Ported to Arduino library by Alexander Emelainov (a.m.emelianov@gmail.com), August 2017

## (It's just a draft and not yet working)